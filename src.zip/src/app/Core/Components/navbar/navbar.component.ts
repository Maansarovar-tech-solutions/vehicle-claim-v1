import { VehicleSearchComponent } from './../../../Modules/add-vehicle/Components/vehicle-search/vehicle-search.component';
import { ActivatedRoute, NavigationEnd, Router, RoutesRecognized } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/Auth/auth.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { filter, map } from 'rxjs/operators';
import { SharedService } from 'src/app/Shared/Services/shared.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  public LoginDetails: any;
  public config = {
    paddingAtStart: true,
    classname: 'my-custom-class',
    listBackgroundColor: `#dad6ff`,
    fontColor: `rgb(8, 54, 71)`,
    backgroundColor: `rgb(208, 241, 239)`,
    selectedListFontColor: `blue`,
    highlightOnSelect: true,
    collapseOnSelect: true,
  };

  public appitems: any = [];
  public pageName: any = '';
  constructor(
    private router: Router,
    private authService: AuthService,
    private sharedService: SharedService,
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog,

  ) {
    this.LoginDetails = JSON.parse(sessionStorage.getItem("Userdetails") || '{}');
    this.router
      .events
      .pipe(filter(event => event instanceof NavigationEnd))
      .pipe(map(() => {
        let child = this.activatedRoute.firstChild;
        while (child) {
          if (child.firstChild) {
            child = child.firstChild;
          } else if (child.snapshot.data && child.snapshot.data['title']) {
            return child.snapshot.data['title'];
          } else {
            return null;
          }
        }
        return null;
      })).subscribe((customData: any) => {
        this.pageName = customData;
        this.sharedService.onGetPageTitle(this.pageName);

      });

  }

  ngOnInit(): void {
    this.appitems = [
      {
        label: 'Masters',
        faIcon: 'fas fa-border-all',

        items: [
          {
            label: 'Make Master',
            link: '/Admin/MakeMaster',
            faIcon: 'fas fa-border-all'
          },
          {
            label: 'Model Master',
            link: '/Admin/ModelMaster',
            faIcon: 'fas fa-border-all'
          },
          {
            label: 'Body Type Master',
            link: '/Admin/BodyTypeMaster',
            faIcon: 'fas fa-border-all'
          },
          {
            label: 'Claim Type Master',
            link: '/Admin/ClaimTypeMaster',
            faIcon: 'fas fa-border-all'
          },
          {
            label: 'Loss Type Master',
            link: '/Admin/LossTypeMaster',
            faIcon: 'fas fa-border-all'
          },
        ]
      },
      {
        label: 'User Creation',
        faIcon: 'fas fa-user-tie',
        link: '/Admin/ExistingUserDetails',
      },

    ]

  }



  addClaim() {
    this.router.navigate(['Home/Add-Vehicle/Claim-Form']);
  }



  onStartNewClaim(name:any) {
    sessionStorage.removeItem("claimEditReq");
    sessionStorage.removeItem("policyEditReq");
    sessionStorage.setItem('claimType',name)
    this.reloadComponent('/Home/Add-Claim/Policy-Form');

  }

  onGetClaimGrid(name:string){
    sessionStorage.setItem('claimType',name)
    // this.router.navigate(['Home/Add-Vehicle/Existing-Claim']);
    this.reloadComponent('Home/Add-Vehicle/Existing-Claim');
  }

  onSearchVehicle() {
    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    // dialogConfig.id = "modal-component";
    dialogConfig.maxWidth = '100vw',
      dialogConfig.maxHeight = '100vh',
      dialogConfig.height = "90%";
    dialogConfig.width = "95%";
    dialogConfig.panelClass = 'full-screen-modal';
    // dialogConfig.data = {
    //   cancelText: 'Cancle',
    //   confirmText: 'Ok',
    //   message: 'VehicleSearchComponent',
    //   title: 'Vehicle Search'
    // }
    const modalDialog = this.dialog.open(VehicleSearchComponent, dialogConfig);

  }



  onLogOut() {
    this.authService.logout();
    sessionStorage.clear();
    this.router.navigate(['Login']);

  }


  reloadComponent(url:string) {
    let currentUrl = url;
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate([currentUrl]);
  }

}
