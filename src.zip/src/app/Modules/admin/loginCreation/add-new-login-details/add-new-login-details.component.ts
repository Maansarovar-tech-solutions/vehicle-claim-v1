import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-login-details',
  templateUrl: './add-new-login-details.component.html',
  styleUrls: ['./add-new-login-details.component.css']
})
export class AddNewLoginDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
