import { Component, OnInit, ViewChild } from '@angular/core';
import { ExcelSaveService } from 'src/app/Shared/Services/excel-save.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';

export interface UserData {
  Amendid: String,
  Branchcode: String,
  Categoryid: String,
  Corecode: String,
  Effectivedate: String,
  Expirydate: String,
  Makeid: String,
  Modelid: String,
  Modelname: String,
  Modelnamearabic: String,
  Referralstatus: String,
  Remarks: String,
  Status: String
}
@Component({
  selector: 'app-model-master',
  templateUrl: './model-master.component.html',
  styleUrls: ['./model-master.component.css']
})
export class ModelMasterComponent implements OnInit {

  displayedColumns: string[] = ['position', 'ModelName','CoreCode','EffectiveDate', 'Status'];
  @ViewChild(MatSort, { static: true })
  sort!: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  dataSource!: MatTableDataSource<UserData>;
  public SearchExsitTable: any;
  public SearchExsitTable1: any;
  modelMasterList:any[]=[];
  constructor(
    private excelService:ExcelSaveService
  ) { 
    this.modelMasterList = [
      {
        "Modelid": "1010",
        "Makeid": "1",
        "Amendid": "0",
        "Modelname": "SEMI TRAILER",
        "Status": "Active",
        "Effectivedate": "10/04/2022",
        "Expirydate": "30/10/2022",
        "Remarks": "3AXLE TRAILE",
        "Branchcode": "01",
        "Corecode": "343",
        "Modelnamearabic": null,
        "Referralstatus": "N",
        "Categoryid": null
      },
      {
        "Modelid": "1011",
        "Makeid": "1",
        "Amendid": "0",
        "Modelname": "TRAILER",
        "Status": "Active",
        "Effectivedate": "22/22/2016",
        "Expirydate": "30/30/2025",
        "Remarks": "3AXLE TRAILE",
        "Branchcode": "01",
        "Corecode": null,
        "Modelnamearabic": null,
        "Referralstatus": "N",
        "Categoryid": null
      },
      {
        "Modelid": "1421",
        "Makeid": "1",
        "Amendid": "0",
        "Modelname": "TANK",
        "Status": "Active",
        "Effectivedate": "26/30/2016",
        "Expirydate": "30/30/2025",
        "Remarks": "testing1",
        "Branchcode": "01",
        "Corecode": "001",
        "Modelnamearabic": null,
        "Referralstatus": "Y",
        "Categoryid": null
      }
    ]
  }

  ngOnInit(): void {
    this.dataSource = new MatTableDataSource(this.modelMasterList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  applyFilter(event: Event) {
    console.log("eValue",event)
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }

  }
  exportAsXLSX():void {  
    this.excelService.exportAsExcelFile(this.modelMasterList, 'ModelMasterDetails');  
 } 

}
