import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(
    private router: Router,

  ) { }

  ngOnInit(): void {
  }

  onNavigation(val:any){
    sessionStorage.removeItem("claimEditReq");
    sessionStorage.removeItem("policyEditReq");
    sessionStorage.setItem('claimType',val)
    if(val === 1){
      this.router.navigate(['/Home/Add-Claim/Policy-Form']);
    }
    if(val === 'Receivable'){
      this.router.navigate(['/Home/Receivable']);
    }
    if(val === 'Payable'){
      this.router.navigate(['/Home/Payable']);
    }
  }


}
