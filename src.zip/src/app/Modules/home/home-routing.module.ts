import { HomeComponent } from './home.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,

  },
  // {
  //   path: 'New-Claim',
  //   loadChildren: () =>
  //     import('./../new-claim/new-claim.module').then((n) => n.NewClaimModule),
  //   data: {
  //     title: "New Claim",
  //     breadcrumb: 'New Claim',
  //   },
  // },
  {
    path: 'Add-Claim',
    loadChildren: () =>
      import('./../add-vehicle/add-vehicle.module').then((n) => n.AddVehicleModule),
      data: {
        title: "New Claim",
        breadcrumb: 'New Claim',
      },
  },

  {
    path: 'Receivable',
    loadChildren: () =>
      import('./../dashboard/dashboard.module').then((n) => n.DashboardModule),
    data: {
      title: "Receivable",
      breadcrumb: 'Receivable',
    },
  },
  {
    path: 'Payable',
    loadChildren: () =>
      import('./../dashboard/dashboard.module').then((n) => n.DashboardModule),
    data: {
      title: "Payable",
      breadcrumb: 'Payable',
    },
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HomeRoutingModule { }
