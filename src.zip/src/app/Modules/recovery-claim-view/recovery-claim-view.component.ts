import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Toaster } from 'ngx-toast-notifications';
import { AddVehicleService } from '../add-vehicle/add-vehicle.service';
import * as Mydatas from '../../app-config.json';

@Component({
  selector: 'app-recovery-claim-view',
  templateUrl: './recovery-claim-view.component.html',
  styleUrls: ['./recovery-claim-view.component.css']
})
export class RecoveryClaimViewComponent implements OnInit {
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;

  public tableData: any[] = [];
  public columnHeader: any[] = [];
  public choosedList: any;
  public userDetails: any;
  public dashboardRadio: any = '';
  public FilterByInsuranceId = 'NIC';
  public insuranceList: any[] = [];

  statusType: any;
  public step: any = '0';
  public startDate:any='12/03/2022';
  public endDate:any='30/05/2022';

  constructor(
    private activatedRoute: ActivatedRoute,
    private addVehicleService: AddVehicleService,
    private datePipe: DatePipe,
    private toaster: Toaster,
    private router: Router

  ) {

    this.dashboardRadio = JSON.parse(sessionStorage.getItem("dashboardRadio") || '{}');


    this.userDetails = JSON.parse(sessionStorage.getItem("Userdetails") || '{}');
    this.activatedRoute.queryParams.subscribe(
      params => {
        console.log(params);
        this.choosedList = params;
      }
    )
  }
  ngOnInit(): void {
    this.onGetExistClaim();
    this.onGetCompanyListCount();
  }

  companyFilter(id: any, insuredId: any) {
    this.step = id;
    this.FilterByInsuranceId = insuredId;
    this.onGetExistClaim();
  }

  daysFilter(event:any){
    event = Number(event);
    var enDate = new Date();
    var startDate = new Date();
    startDate.setDate(startDate.getDate() - 10);

    var endDD = String(enDate.getDate()).padStart(2, '0');
    var endMM = String(enDate.getMonth() + 1).padStart(2, '0');
    var endYYYY = enDate.getFullYear();

    var startDD = String(startDate.getDate()).padStart(2, '0');
    var startMM = String(startDate.getMonth() + 1).padStart(2, '0');
    var startYYYY = startDate.getFullYear();


    this.startDate = startDD + '/' + startMM + '/' + startYYYY;
    this.endDate = endDD + '/' + endMM + '/' + endYYYY;
    console.log(this.startDate,this.endDate);
    if(event ==0){
      this.startDate='12/03/2022';
      this.endDate='30/05/2022';

    }
    this.onGetExistClaim();
    this.onGetCompanyListCount();
  }

  onGetCompanyListCount() {
    let UrlLink = `${this.ApiUrl1}api/companies/count/datewise`;
    let userDetails = this.userDetails?.LoginResponse;
    let ReqObj = {
      "InsuranceId": userDetails?.InsuranceId,
      "StatusCode": this.choosedList?.StatusCode,
      "Claim": this.dashboardRadio.name,
      "StartDate": this.startDate,
      "EndDate": this.endDate

    }
    this.addVehicleService.onPostMethodSync(UrlLink, ReqObj).subscribe(
      (data: any) => {
        if (data?.Message == "Success") {
          console.log(data)
          this.insuranceList = data?.Result;
        }
      },
      (err) => { }
    );
  }





  onGetExistClaim() {

    let UrlLink = `${this.ApiUrl1}api/company/datewise`;
    let userDetails = this.userDetails?.LoginResponse;
    let ReqObj = {
      "InsuranceId": userDetails?.InsuranceId,
      "StatusCode": this.choosedList?.StatusCode,
      "Claim": this.dashboardRadio.name,
      "FilterByInsuranceId": this.FilterByInsuranceId,
      "StartDate": this.startDate,
      "EndDate": this.endDate

    }
    this.addVehicleService.onPostMethodSync(UrlLink, ReqObj).subscribe(
      (data: any) => {
        if (data?.Message == "Success") {
          console.log(data)
          this.onLoadData(data.Result)

        }
      },
      (err) => { }
    );
  }

  onLoadData(data: any[]) {
    console.log(this.dashboardRadio.name)
    if (this.dashboardRadio.name == 'Receivable') {
      this.columnHeader = [
        {
          key: "actions", display: "Actions",
          config: {
            isEdit: true,
          },
        },
        { key: "ClaimNumber", display: "Claim Number" },
        { key: "CivilId", display: "Civil Id" },
        { key: "PolicyNumber", display: "Policy Number" },
        { key: "VehicleChassisNumber", display: "Chassis Number" },
        { key: "RecoveryCompanyName", display: "Insured Company" },
        { key: "AccidentDate", display: "Accident Date" },
        { key: "ClaimIntimatedDate", display: "Intimate Date" },

      ];
      this.tableData = data;

    }
    if (this.dashboardRadio.name == 'Payable') {
      this.columnHeader = [
        {
          key: "actions", display: "Actions",
          config: {
            isEdit: true,
          },
        },
        { key: "ClaimNumber", display: "Claim Number" },
        { key: "CivilId", display: "Civil Id" },
        { key: "PolicyNumber", display: "Policy Number" },
        { key: "VehicleChassisNumber", display: "Chassis Number" },
        { key: "InsuranceCompanyName", display: "Insured Company" },
        { key: "AccidentDate", display: "Accident Date" },
        { key: "ClaimIntimatedDate", display: "Intimate Date" },

      ];
      this.tableData = data;




    }
  }
  onTrack(event: any) {
    this.router.navigate(['/Home/Track'], { queryParams: event });

  }


  onTplEdit(event: any) {
    sessionStorage.setItem('claimEditReq', JSON.stringify(event));
    this.router.navigate(['/Home/Add-Vehicle/Claim-Form']);
  }

  onProcced(event: any) {
    console.log(event)
    this.router.navigate(['Home/Receivable/recovery-claim-grid/Claim-Details'],{queryParams:event});
  }
}
