import { ClaimStatusComponent } from './../claim-status/claim-status.component';
import { RecoveryClaimViewComponent } from './recovery-claim-view.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: RecoveryClaimViewComponent,

  },
  {
    path: 'Claim-Details',
    component: ClaimStatusComponent,
    data: {
      title: "Claim-Details",
      breadcrumb: 'Claim-Details',
    },
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RecoveryClaimViewRoutingModule {}
