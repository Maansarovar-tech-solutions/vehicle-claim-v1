import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-statement',
  templateUrl: './account-statement.component.html',
  styleUrls: ['./account-statement.component.css']
})
export class AccountStatementComponent implements OnInit {
  public check1:boolean=true;
  public check2:boolean=false;
  public check3:boolean=false;
  constructor() { }

  ngOnInit(): void {
  }

}
