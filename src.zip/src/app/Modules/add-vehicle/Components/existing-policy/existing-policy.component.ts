import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AddVehicleService } from '../../add-vehicle.service';
import * as Mydatas from '../../../../app-config.json';
export interface PeriodicElement {
  "PolicyReferenceNumber": string | null,
  "PolicyNumber": string | null,
  "CivilId": string | null,
  "InsuranceTypeId": string | null,
  "InsuranceTypeDesc": string | null,
  "InsuranceStartDate": string | null,
  "InsuranceEndDate": string | null,
  "EntryDate": string | null,
  "VehicleDetails": [
    {
      "VehicleChassisNumber": string | null,
      "Status": string | null,
      "VehicleCode": string | null,
      "VehicleMakeId": string | null,
      "VehicleMakeDesc": string | null,
      "VehicleModelId": string | null,
      "VehicleModelDesc": string | null,
      "RegistrationTypeId": string | null,
      "RegistrationTypeDesc": string | null,
      "VehicleBodyId": string | null,
      "VehicleBodyDesc": string | null,
      "ManufactureYear": string | null,
      "ColorId": string | null,
      "ColorDesc": string | null,
      "PlateCode": string | null,
      "PlateCharacter": string | null,
      "PlateNumber": string | null,
      "VehicleEngineNumber": string | null,
      "EntryDate": string | null,
      "Remarks": string | null,
    }
  ]
}
@Component({
  selector: 'app-existing-policy',
  templateUrl: './existing-policy.component.html',
  styleUrls: ['./existing-policy.component.css']
})
export class ExistingPolicyComponent implements OnInit {
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public userDetails: any;
  public policyList: PeriodicElement[] = [];
  public columnHeader: any[] = [];
  public policyEditReq: any;

  constructor(
    private addVehicleService: AddVehicleService,
    private activatedRoute: ActivatedRoute,
    private router: Router

  ) {
    this.userDetails = JSON.parse(sessionStorage.getItem("Userdetails") || '{}');
    var snapshot = this.activatedRoute.snapshot;
    const params = { ...snapshot.queryParams };
    delete params.pos;
    this.policyEditReq = params;
  }

  ngOnInit(): void {
    // this.onGetPolicyList();
    this.onGetPolicyDataList();

  }

  // onGetPolicyList() {
  //   let userDetails = this.userDetails?.LoginResponse;
  //   let UrlLink = `${this.ApiUrl1}api/policyinfo/datewise`;
  //   let ReqObj = {
  //     "BranchCode": userDetails?.BranchCode,
  //     "InsuranceId": userDetails?.InsuranceId,
  //     "RegionCode": userDetails?.RegionCode,
  //     "StartDate": "12/03/2022",
  //     "EndDate": "30/05/2022"
  //   }
  //   this.addVehicleService.onPostMethodSync(UrlLink, ReqObj).subscribe(
  //     (data: any) => {
  //       this.columnHeader = [
  //         { key: "PolicyNumber", display: "Policy No" },
  //         { key: "CivilId", display: "Civil Id" },
  //         {
  //           key: "PlateCode", display: "Plate Number/Plate Char",
  //           config: {
  //             isCodeChar: true,
  //           },
  //         },
  //         {
  //           key: "VehicleChassisNumber", display: "Chassis Number",

  //         },
  //         { key: "InsuranceEndDate", display: "Expairy Date" },

  //         {
  //           key: "actions", display: "Edit",
  //           config: {
  //             isEditActions: true,
  //           },
  //         },
  //       ];
  //       this.policyList = data?.Result;
  //     },
  //     (err) => { }
  //   );
  // }


  onEditPolicy(event: any) {
    delete event?.policy?.VehicleDetails;
    let obj={
      ...event.policy,
      ...event?.Vehicle,
    }
    sessionStorage.setItem('policyEditReq',JSON.stringify(event));
    this.router.navigate(['/Home/Add-Vehicle/Policy-Form'],{queryParams:obj,skipLocationChange:true});
  }


  onGetPolicyDataList() {
    let userDetails = this.userDetails?.LoginResponse;
    let UrlLink = `${this.ApiUrl1}api/policyinfos/datewise`;
    let ReqObj = {
      "BranchCode": userDetails?.BranchCode,
      "InsuranceId": userDetails?.InsuranceId,
      "RegionCode": userDetails?.RegionCode,
      "StartDate": "12/03/2022",
      "EndDate": "05/05/2022"
    }
    this.addVehicleService.onPostMethodSync(UrlLink, ReqObj).subscribe(
      (data: any) => {
        console.log(data)
        this.columnHeader = [
          {
            key: "view", display: "Vehicle List",
            config: {
              isMoreView: true,
            },
          },
          { key: "PolicyNumber", display: "Policy No" },
          { key: "CivilId", display: "Civil Id" },
          { key: "InsuranceTypeDesc", display: "Insurance Type" },
          { key: "InsuranceEndDate", display: "Expairy Date" },


        ];
        this.policyList = data?.Result;
      },
      (err) => { }
    );
  }

}
