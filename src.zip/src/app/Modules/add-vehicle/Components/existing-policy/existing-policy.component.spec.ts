import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingPolicyComponent } from './existing-policy.component';

describe('ExistingPolicyComponent', () => {
  let component: ExistingPolicyComponent;
  let fixture: ComponentFixture<ExistingPolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExistingPolicyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingPolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
