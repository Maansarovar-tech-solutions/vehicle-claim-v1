import { AddVehicleService } from './../../add-vehicle.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as Mydatas from '../../../../app-config.json';
import { DatePipe } from '@angular/common';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { Toaster } from 'ngx-toast-notifications';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-tpl-form',
  templateUrl: './tpl-form.component.html',
  styleUrls: ['./tpl-form.component.css']
})
export class TplFormComponent implements OnInit {

  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public tplForm!: FormGroup;
  public userDetails: any;
  public searchValue: any = '';
  public isVehicleData:boolean = false;
  public vehicleData:any;

  public claimTypeList: any[] = [];
  public filterclaimTypeList!: Observable<any[]>;
  public AccidentNumber:any='';
  constructor(
    private _formBuilder: FormBuilder,
    private addVehicleService: AddVehicleService,
    private datePipe: DatePipe,
    private toaster: Toaster,
    private activatedRoute: ActivatedRoute,
    private router:Router


  ) {
    this.userDetails = JSON.parse(sessionStorage.getItem("Userdetails") || '{}');

  }

  ngOnInit(): void {
    this.onCreateFormControl();
    this.onGetClaimTypeList();
    this.activatedRoute.queryParams.subscribe(
      params => {
        console.log(params);
        this.searchValue = params?.VehicleChassisNumber;
        this.onSearchVehicle();
        this.onClaimEdit(params)
      }
    )
  }



  onCreateFormControl() {
    this.tplForm = this._formBuilder.group({
      AccidentDate: ['', Validators.required],
      AccidentLocation: ['', Validators.required],
      AccidentDescription: ['', Validators.required],
      ClaimTypeId: ['', Validators.required],
      ReserveAmount: ['', Validators.required],
      ClaimNumber: ['', Validators.required],

      LicenceNumber: ['', Validators.required],
      DriverDateOfBirth: ['', Validators.required],
      LicenceValidUpto: ['', Validators.required],
      Gender: ['1', Validators.required],
    });
  }
  get f() { return this.tplForm.controls; };

  onGetClaimTypeList() {
    let UrlLink = `${this.ApiUrl1}dropdown/claimtypes`
    this.addVehicleService.onGetMethodSync(UrlLink).subscribe(
      (data: any) => {
        this.claimTypeList = data?.Result;
        this.filterclaimTypeList = this.f.ClaimTypeId.valueChanges.pipe(
          startWith(''),
          map((value) => this._filter(value, this.claimTypeList)),
        );
      },
      (err) => { }
    );
  }
  claimTypeText = (option: any) => {
    if (!option) return '';
    let index = this.claimTypeList.findIndex((make: any) => make.Code == option);
    return this.claimTypeList[index].CodeDescription;
  }


  private _filter(value: any, data: any[]): any[] {
    if (value == null) {
      value = '';
    }
    const filterValue = value.toLowerCase();
    return data.filter((option) => option?.CodeDescription?.toLowerCase().includes(filterValue));
  }

  onSearchVehicle() {
    let UrlLink = `${this.ApiUrl1}api/searchvehicleinfo`;
    let ReqObj = {
      "VehicleChassisNumber": this.searchValue
    }
    this.addVehicleService.onPostMethodSync(UrlLink, ReqObj).subscribe(
      (data: any) => {
         if(data?.Message== "Success"){
              this.isVehicleData = true;
              this.vehicleData=data?.Result?.VehicleDetails;
         }
      },
      (err) => { }
    );
  }

  onDateFormatt(data: any) {
    data.split("/").reverse().join("-")
    console.log(new Date(data))
    return new Date(data);
  }

  onClaimEdit(claim:any){
    let UrlLink = `${this.ApiUrl1}api/claiminfo/get`;
    let ReqObj = {
      "InsuranceId": claim?.InsuranceId,
      "BranchCode": claim?.BranchCode,
      "RegionCode": claim?.RegionCode,
      "ClaimNumber":claim?.ClaimNumber,
      "AccidentNumber":claim?.AccidentNumber,

    };
    this.addVehicleService.onPostMethodSync(UrlLink, ReqObj).subscribe(
      (data: any) => {
        console.log(data)
        if (data?.Message == "Success") {

          let AccidentInformation = data?.Result?.AccidentInformation;
          let DriverInformation = data?.Result?.DriverInformation;
          this.f.AccidentDate.setValue( this.onDateFormatt(AccidentInformation?.AccidentDate))
          this.f.AccidentLocation.setValue(AccidentInformation?.AccidentLocation)
          this.f.AccidentDescription.setValue(AccidentInformation?.AccidentDescription)
          this.f.ClaimTypeId.setValue(AccidentInformation?.ClaimTypeId)
          this.f.ReserveAmount.setValue(AccidentInformation?.ReserveAmount)
          this.f.ClaimNumber.setValue(AccidentInformation?.ClaimNumber)

          this.f.LicenceNumber.setValue(DriverInformation?.LicenceNumber)
          this.f.DriverDateOfBirth.setValue(this.onDateFormatt(DriverInformation?.DriverDateOfBirth))
          this.f.LicenceValidUpto.setValue(this.onDateFormatt(DriverInformation?.LicenceValidUpto))
          this.f.Gender.setValue(DriverInformation?.Gender)
          this.AccidentNumber=AccidentInformation?.AccidentNumber;


        }
      },
      (err) => { }
    );
  }


  onSaveClaimInfo() {
    let userDetails = this.userDetails?.LoginResponse;

    let UrlLink = `${this.ApiUrl1}api/claim/pushaccidentinfo`;
    let ReqObj = {
      "AccidentInformation": {
        "AccidentNumber": this.AccidentNumber,
        "AccidentDate": this.datePipe.transform(this.f.AccidentDate.value, "dd/MM/yyyy"),
        "AccidentDescription": this.f.AccidentDescription.value,
        "AccidentLocation": this.f.AccidentLocation.value,
        "ClaimNumber": this.f.ClaimNumber.value,
        "ReserveAmount": this.f.ReserveAmount.value,
        "ClaimTypeId": this.f.ClaimTypeId.value,
      },
      "CommonInformation": {
        "BranchCode": userDetails?.BranchCode,
        "CreatedBy": userDetails?.LoginId,
        "InsuranceId": userDetails?.InsuranceId,
        "RegionCode": userDetails?.RegionCode,
        "VehicleChassisNumber": this.vehicleData?.VehicleChassisNumber,
        "VehicleCode": this.vehicleData?.VehicleCode
      },
      "DriverInformation": {
        "DriverDateOfBirth": this.datePipe.transform(this.f.DriverDateOfBirth.value, "dd/MM/yyyy"),
        "Gender": this.f.Gender.value,
        "LicenceNumber": this.f.LicenceNumber.value,
        "LicenceValidUpto": this.datePipe.transform(this.f.LicenceValidUpto.value, "dd/MM/yyyy"),
      }
    }
    console.log(ReqObj)
    this.addVehicleService.onPostMethodSync(UrlLink, ReqObj).subscribe(
      (data: any) => {
       if(data?.Message == 'Success'){
       console.log(data)

        if(data?.Result?.Response =='Saved Successfully'){
          console.log(data?.Result?.Response)
         this.toaster.open({
           text: 'Claim Intimated Successfully',
           caption: 'Submitted',
           type: 'success',
         });
        }
        this.router.navigate(['Home/Add-Vehicle/Existing-Claim']);

    }

      },
      (err) => { }
    );
  }


}
