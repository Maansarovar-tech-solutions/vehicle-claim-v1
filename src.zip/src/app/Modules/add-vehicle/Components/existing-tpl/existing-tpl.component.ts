import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-existing-tpl',
  templateUrl: './existing-tpl.component.html',
  styleUrls: ['./existing-tpl.component.css']
})
export class ExistingTplComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
