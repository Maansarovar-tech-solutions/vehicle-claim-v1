import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingTplComponent } from './existing-tpl.component';

describe('ExistingTplComponent', () => {
  let component: ExistingTplComponent;
  let fixture: ComponentFixture<ExistingTplComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExistingTplComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingTplComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
