import { AddVehicleService } from './../../add-vehicle.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as Mydatas from '../../../../app-config.json';

@Component({
  selector: 'app-vehicle-search',
  templateUrl: './vehicle-search.component.html',
  styleUrls: ['./vehicle-search.component.css']
})
export class VehicleSearchComponent implements OnInit {
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public chassisForm!: FormGroup;
  public civilForm!: FormGroup;
  public selectedTab: string = 'Chassis Number';
  public LoginDetails: any;
  public searchedDetails:any[]=[];
  constructor(
    private formBuilder: FormBuilder,
    private addVehicleService: AddVehicleService

  ) {
    this.LoginDetails = JSON.parse(sessionStorage.getItem("Userdetails") || '{}');

  }

  ngOnInit(): void {
    this.onCreateFormControl();
  }

  onCreateFormControl() {
    this.chassisForm = this.formBuilder.group({
      chassisno: ['', Validators.required],
    });
    this.civilForm = this.formBuilder.group({
      civilno: ['', Validators.required],
    });
  }

  get f() { return this.chassisForm.controls; };
  get f1() { return this.civilForm.controls; };


  onTabChanged(event: any) {
    console.log(event.tab.textLabel)
    this.selectedTab = event.tab.textLabel;
    this.searchedDetails=[];
  }


  onSearchDetails() {
    var UrlLink = '';
    var ReqObj = {};
    if (this.selectedTab == 'Chassis Number') {
      if (this.chassisForm.valid) {
        UrlLink = `${this.ApiUrl1}totalloss/vehicleIinfo/bychassisno`;
        ReqObj = {
          "ChassisNo": this.chassisForm.controls['chassisno'].value
        }
      }

    }
    if (this.selectedTab == 'Civil Id') {
      if (this.civilForm.valid) {
        UrlLink = `${this.ApiUrl1}totalloss/vehicleInfo/bycivilid`;
        ReqObj = {
          "CivilId": this.civilForm.controls['civilno'].value
        }
      }

    }

    return this.addVehicleService.onPostMethodSync(UrlLink, ReqObj).subscribe((data: any) => {
       console.log(data)
       this.searchedDetails = data?.VehicleInfoList;
    }, (err) => { })
  }


}
