import { PageHeaderModule } from './../../Shared/Header/page-header.module';
import { VehicleSearchComponent } from './Components/vehicle-search/vehicle-search.component';
import { ButtonsModule } from './../../Shared/Buttons/buttons.module';
import { AddVehicleRoutingModule } from './add-vehicle-routing.module';
import { AddVehicleComponent } from './add-vehicle.component';
import { IconsModule } from './../../Shared/Icons/icons.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, DatePipe } from '@angular/common';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import { MaterialModule } from 'src/app/Shared/material/material.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgModule } from '@angular/core';
import { NgApexchartsModule } from 'ng-apexcharts';
import { PolicyFormComponent } from './Components/policy-form/policy-form.component';
import { ClaimFormComponent } from './Components/claim-form/claim-form.component';
import { TplFormComponent } from './Components/tpl-form/tpl-form.component';
import { ExistingPolicyComponent } from './Components/existing-policy/existing-policy.component';
import { ExistingClaimComponent } from './Components/existing-claim/existing-claim.component';
import { ExistingTplComponent } from './Components/existing-tpl/existing-tpl.component';
import { TablesModule } from 'src/app/Shared/Tables/tables.module';

@NgModule({
  declarations: [
    AddVehicleComponent,
    PolicyFormComponent,
    ClaimFormComponent,
    TplFormComponent,
    ExistingPolicyComponent,
    ExistingClaimComponent,
    ExistingTplComponent,
    VehicleSearchComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgSelectModule,
    NgApexchartsModule,
    IconsModule,
    AddVehicleRoutingModule,
    ButtonsModule,
    TablesModule,
    PageHeaderModule

  ],

  providers: [DatePipe, { provide: MAT_DATE_LOCALE, useValue: 'en-GB' }],
  bootstrap: [AddVehicleComponent],
})
export class AddVehicleModule { }
