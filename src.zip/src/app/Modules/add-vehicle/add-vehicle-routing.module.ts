import { ExistingTplComponent } from './Components/existing-tpl/existing-tpl.component';
import { ExistingClaimComponent } from './Components/existing-claim/existing-claim.component';
import { AddVehicleComponent } from './add-vehicle.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PolicyFormComponent } from './Components/policy-form/policy-form.component';
import { ClaimFormComponent } from './Components/claim-form/claim-form.component';
import { TplFormComponent } from './Components/tpl-form/tpl-form.component';
import { ExistingPolicyComponent } from './Components/existing-policy/existing-policy.component';

const routes: Routes = [
  {
    path: '',
    component: AddVehicleComponent,
  },
  {
    path: 'Policy-Form',
    component: PolicyFormComponent,
    data: {
      title: "Recovery Claim",
      breadcrumb: 'Recovery Claim',
    },
  },
  {
    path: 'Claim-Form',
    component: ClaimFormComponent,
    data: {
      title: "Claim",
    },
  },
  {
    path: 'Tpl-Form',
    component: TplFormComponent,
    data: {
      title: "TPL Recovery",
    },
  },
  {
    path: 'Existing-Policy',
    component: ExistingPolicyComponent,
    data: {
      title: "Total Recovery Claim",
    },
  },
  {
    path: 'Existing-Claim',
    component: ExistingClaimComponent,
    data: {
      title: "Existing Claim",
    },
  },
  {
    path: 'Existing-Tpl',
    component: ExistingTplComponent,
    data: {
      title: "Existing TPL Recovery",
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AddVehicleRoutingModule {}
