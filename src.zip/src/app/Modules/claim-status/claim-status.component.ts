import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import * as Mydatas from '../../app-config.json';
import { AddVehicleService } from '../add-vehicle/add-vehicle.service';
@Component({
  selector: 'app-claim-status',
  templateUrl: './claim-status.component.html',
  styleUrls: ['./claim-status.component.css']
})
export class ClaimStatusComponent implements OnInit {
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public claimStatusList: any[] = [];
  public filterclaimStatusList!: Observable<any[]>;
  public claimStatusForm!: FormGroup;
  public userDetails: any;
  public claimDetails: any;
  public claimInformation:any;
  public commonInformation:any;

  public accidentInformation:any;
  public driverInformation:any;
  public policyInformation:any;
  public recoveryInformation:any;
  public vehicleInformation:any;
  public statusName:any='';
  public recoveryType:any='';
  constructor(
    private _formBuilder: FormBuilder,
    private addVehicleService: AddVehicleService,
    private activatedRoute: ActivatedRoute,
    private router:Router

  ) {
    this.userDetails = JSON.parse(sessionStorage.getItem("Userdetails") || '{}');
    this.recoveryType=sessionStorage.getItem("claimType");


    this.activatedRoute.queryParams.subscribe(
      (params: any) => {
        console.log(params)
        this.claimDetails=params;
        this.onGetClaimDetails(params)
      }
    );

  }

  ngOnInit(): void {
    this.onCreateFormControl();
    this.onFetchInitialData();
  }

  onCreateFormControl() {
    this.claimStatusForm = this._formBuilder.group({
      claimStatus: ['', Validators.required],
      claimStatusRemarks: ['', Validators.required],

    });
  }
  get f() { return this.claimStatusForm.controls; };

  async onFetchInitialData(){
  this.claimStatusList = await this.onGetInsuranceStatusList()||[];
  // let index = this.claimStatusList.findIndex((ele:any)=>ele.StatusCode == this.f.claimStatus.value);
  // console.log(index)
  // this.statusName = this.claimStatusList[index].StatusDesc;
  }

  private _filter(value: any, data: any[]): any[] {
    if (value == null) {
      value = '';
    }
    const filterValue = value.toLowerCase();
    return data.filter((option) => option?.CodeDesc?.toLowerCase().includes(filterValue));
  }

  claimStatusText = (option: any) => {
    if (!option) return '';
    let index = this.claimStatusList.findIndex((make: any) => make.Code == option);
    return this.claimStatusList[index].CodeDesc;
  }

  onGetStatusName(val: any) {
    this.statusName=val;
  }

  async onGetInsuranceStatusList() {
    let UrlLink = `${this.ApiUrl1}api/dropdown/claimstatus`
    let response = (await this.addVehicleService.onGetMethodAsync(UrlLink)).toPromise()
      .then((res: any) => {
        return res?.Result;
      })
      .catch((err) => { });
    return response;
  }
  onUpdateClaimStatus() {
    let userDetails = this.userDetails?.LoginResponse;
    let UrlLink = `${this.ApiUrl1}api/update/status`;
    let ReqObj = {
      "ClaimReferenceNumber": this.claimDetails?.ClaimReferenceNumber,
      "UpdatedBy": userDetails?.LoginId,
      "InsuranceId": userDetails?.InsuranceId,
      "StatusCode": this.f.claimStatus.value,
      "Remarks":this.f.claimStatusRemarks.value
    }
    this.addVehicleService.onPostMethodSync(UrlLink, ReqObj).subscribe(
      (data: any) => {
        console.log(data)
        if(data?.Message == 'Success'){
          this.router.navigate(['Home/Dashboard']);

        }
      },
      (err) => { }
    );
  }


  onGetClaimDetails(event:any) {
    let userDetails = this.userDetails?.LoginResponse;
    let UrlLink = `${this.ApiUrl1}api/view/claim`;
    let ReqObj = {
      "ClaimReferenceNumber": event?.ClaimReferenceNumber

    }
    this.addVehicleService.onPostMethodSync(UrlLink, ReqObj).subscribe(
      (data: any) => {
        console.log(data)
        if(data?.Message == 'Success'){
          this.claimInformation=data?.Result;
          this.commonInformation = this.claimInformation?.CommonInformation;
          this.accidentInformation=this.claimInformation?.AccidentInformation;
          this.driverInformation=this.claimInformation?.DriverInformation;
          this.policyInformation=this.claimInformation?.PolicyInformation;
          this.recoveryInformation=this.claimInformation?.RecoveryInformation;
          this.vehicleInformation=this.claimInformation?.VehicleInformation;
        }
      },
      (err) => { }
    );
  }
}
